import AccessTime from "@mui/icons-material/AccessTime";

const Timings = () =>{
    <AccessTime/>
}

export default Timings